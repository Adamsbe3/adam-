import React, { Component } from "react";
import styled, { css } from "styled-components";
import CupertinoButtonInfo from "../components/CupertinoButtonInfo";

function Untitled(props) {
  return (
    <>
      <ImageStack>
        <Image>
          <Image2StackRow>
            <Image2Stack>
              <Image2 src={require("../assets/images/Group_1.png")}></Image2>
              <Start>Start</Start>
            </Image2Stack>
            <Home>Home</Home>
            <Portfolio>Portfolio</Portfolio>
            <Services>Services</Services>
            <Contact>Contact</Contact>
          </Image2StackRow>
        </Image>
        <Works>WORKS</Works>
      </ImageStack>
      <CupertinoButtonInfoStack>
        <CupertinoButtonInfo
          style={{
            height: 46,
            width: 135,
            position: "absolute",
            top: 0,
            left: 646
          }}
        ></CupertinoButtonInfo>
        <Image7Stack>
          <Image7>
            <Image13StackRow>
              <Image13Stack>
                <Image13
                  src={require("../assets/images/Group_35.png")}
                ></Image13>
                <Image14
                  src={require("../assets/images/Group_34.png")}
                ></Image14>
                <Image15
                  src={require("../assets/images/Group_33.png")}
                ></Image15>
              </Image13Stack>
              <Image10Stack>
                <Image10
                  src={require("../assets/images/Group_38.png")}
                ></Image10>
                <Image11
                  src={require("../assets/images/Group_37.png")}
                ></Image11>
                <Image12
                  src={require("../assets/images/Group_36.png")}
                ></Image12>
              </Image10Stack>
              <Image9 src={require("../assets/images/Group_39.png")}></Image9>
            </Image13StackRow>
          </Image7>
          <Image24
            src={require("../assets/images/©_LOGO,_2019._All_ri1.png")}
          ></Image24>
        </Image7Stack>
      </CupertinoButtonInfoStack>
      <Image16StackStack>
        <Image16Stack>
          <Image16 src={require("../assets/images/dscdscd_1.png")}></Image16>
          <LoremIpsum>
            Lorem ipsum, dolor sit amet consectetur{"\n"}adipisicing elit.
          </LoremIpsum>
        </Image16Stack>
        <Image17 src={require("../assets/images/Group_41.png")}></Image17>
      </Image16StackStack>
      <Image18StackRow>
        <Image18Stack>
          <Image18 src={require("../assets/images/Frame_43.png")}></Image18>
          <Image20 src={require("../assets/images/Frame_43_(2).png")}></Image20>
          <Image22 src={require("../assets/images/dscdsc_1.png")}></Image22>
        </Image18Stack>
        <Image19Column>
          <Image19 src={require("../assets/images/Frame_43_(1).png")}></Image19>
          <Image21
            src={require("../assets/images/Frame_43_(3)1.png")}
          ></Image21>
          <Image23 src={require("../assets/images/5175975_1.png")}></Image23>
        </Image19Column>
      </Image18StackRow>
      <Portfolio2>Portfolio</Portfolio2>
    </>
  );
}

const Image = styled.div`
  top: 0px;
  left: 0px;
  width: 1414px;
  height: 163px;
  position: absolute;
  flex-direction: row;
  display: flex;
  background-image: url(${require("../assets/images/Rectangle1.png")});
  background-size: cover;
`;

const Image2 = styled.img`
  top: 6px;
  left: 0px;
  width: 95px;
  height: 32px;
  position: absolute;
  object-fit: contain;
`;

const Start = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 84px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: rgba(255,255,255,1);
  font-size: 36px;
`;

const Image2Stack = styled.div`
  width: 162px;
  height: 43px;
  position: relative;
`;

const Home = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(255,255,255,1);
  font-size: 25px;
  margin-left: 643px;
  margin-top: 7px;
`;

const Portfolio = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(255,255,255,1);
  font-size: 25px;
  margin-left: 25px;
  margin-top: 8px;
`;

const Services = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(255,255,255,1);
  font-size: 25px;
  margin-left: 27px;
  margin-top: 8px;
`;

const Contact = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(255,255,255,1);
  font-size: 25px;
  margin-left: 33px;
  margin-top: 10px;
`;

const Image2StackRow = styled.div`
  height: 43px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 72px;
  margin-left: 108px;
  margin-top: 68px;
`;

const Works = styled.span`
  font-family: Verdana;
  top: 149px;
  left: 650px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: rgba(116,198,157,1);
  font-size: 24px;
  letter-spacing: 5px;
`;

const ImageStack = styled.div`
  width: 1414px;
  height: 178px;
  margin-top: -51px;
  margin-left: -8px;
  position: relative;
`;

const Image7 = styled.div`
  top: 44px;
  left: 0px;
  width: 1414px;
  height: 110px;
  position: absolute;
  flex-direction: row;
  display: flex;
  background-image: url(${require("../assets/images/Rectangle1.png")});
  background-size: cover;
`;

const Image13 = styled.img`
  top: 5px;
  left: 104px;
  width: 51px;
  height: 26px;
  position: absolute;
  object-fit: contain;
`;

const Image14 = styled.img`
  top: 3px;
  left: 47px;
  width: 81px;
  height: 27px;
  position: absolute;
  object-fit: contain;
`;

const Image15 = styled.img`
  top: 0px;
  left: 0px;
  width: 93px;
  height: 30px;
  position: absolute;
  object-fit: contain;
`;

const Image13Stack = styled.div`
  width: 155px;
  height: 31px;
  margin-top: 8px;
  position: relative;
`;

const Image10 = styled.img`
  top: 0px;
  left: 73px;
  width: 24px;
  height: 46px;
  position: absolute;
  object-fit: contain;
`;

const Image11 = styled.img`
  top: 11px;
  left: 15px;
  width: 70px;
  height: 27px;
  position: absolute;
  object-fit: contain;
`;

const Image12 = styled.img`
  top: 11px;
  left: 0px;
  width: 40px;
  height: 27px;
  position: absolute;
  object-fit: contain;
`;

const Image10Stack = styled.div`
  width: 97px;
  height: 46px;
  margin-left: 1px;
  position: relative;
`;

const Image9 = styled.img`
  width: 100%;
  height: 39px;
  margin-left: 12px;
  margin-top: 4px;
  object-fit: contain;
`;

const Image13StackRow = styled.div`
  height: 46px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1006px;
  margin-left: 105px;
  margin-top: 29px;
`;

const Image24 = styled.img`
  top: 0px;
  left: 1011px;
  width: 345px;
  height: 200px;
  position: absolute;
  object-fit: contain;
`;

const Image7Stack = styled.div`
  top: 42px;
  left: 0px;
  width: 1414px;
  height: 200px;
  position: absolute;
`;

const CupertinoButtonInfoStack = styled.div`
  width: 1414px;
  height: 242px;
  margin-top: 1983px;
  margin-left: -14px;
  position: relative;
`;

const Image16 = styled.img`
  top: 43px;
  left: 0px;
  width: 586px;
  height: 450px;
  position: absolute;
  object-fit: contain;
`;

const LoremIpsum = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 412px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 22px;
  text-align: center;
`;

const Image16Stack = styled.div`
  top: 0px;
  left: 0px;
  width: 807px;
  height: 493px;
  position: absolute;
`;

const Image17 = styled.img`
  top: 98px;
  left: 629px;
  width: 606px;
  height: 340px;
  position: absolute;
  object-fit: contain;
`;

const Image16StackStack = styled.div`
  width: 1235px;
  height: 493px;
  margin-top: -2144px;
  margin-left: 89px;
  position: relative;
`;

const Image18 = styled.img`
  top: 0px;
  left: 0px;
  width: 586px;
  height: 381px;
  position: absolute;
  object-fit: contain;
`;

const Image20 = styled.img`
  top: 220px;
  left: 2px;
  width: 586px;
  height: 804px;
  position: absolute;
  object-fit: contain;
`;

const Image22 = styled.img`
  top: 835px;
  left: 0px;
  width: 586px;
  height: 481px;
  position: absolute;
  object-fit: contain;
`;

const Image18Stack = styled.div`
  width: 589px;
  height: 1316px;
  position: relative;
`;

const Image19 = styled.img`
  width: 586px;
  height: 100%;
  margin-left: 9px;
  object-fit: contain;
`;

const Image21 = styled.img`
  width: 586px;
  height: 100%;
  margin-top: 29px;
  margin-left: 2px;
  object-fit: contain;
`;

const Image23 = styled.img`
  width: 589px;
  height: 100%;
  margin-top: 22px;
  object-fit: contain;
`;

const Image19Column = styled.div`
  width: 596px;
  flex-direction: column;
  display: flex;
  margin-left: 50px;
  margin-bottom: 24px;
`;

const Image18StackRow = styled.div`
  height: 1316px;
  flex-direction: row;
  display: flex;
  margin-left: 89px;
  margin-right: 76px;
`;

const Portfolio2 = styled.span`
  font-family: Andada Pro;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 43px;
  margin-top: -1872px;
  margin-left: 609px;
`;

export default Untitled;
