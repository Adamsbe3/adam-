import React, { Component } from "react";
import styled, { css } from "styled-components";

function CupertinoButtonInfo(props) {
  return (
    <Container {...props}>
      <LearnMore>Learn more</LearnMore>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(41,45,50,0.92);
  justify-content: center;
  align-items: center;
  flex-direction: row;
  padding-left: 16px;
  padding-right: 16px;
  shadow-radius: 0px;
  box-shadow: 3px 3px 0px  0.01px rgba(0,0,0,1) ;
`;

const LearnMore = styled.span`
  font-family: Roboto;
  color: #fff;
  font-size: 17px;
  font-weight: 500;
  margin: 0px;
`;

export default CupertinoButtonInfo;
